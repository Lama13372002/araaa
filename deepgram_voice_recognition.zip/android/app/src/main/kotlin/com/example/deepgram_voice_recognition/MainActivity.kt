package com.example.deepgram_voice_recognition

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
