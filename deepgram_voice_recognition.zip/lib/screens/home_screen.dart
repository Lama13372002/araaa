import 'package:flutter/material.dart';
import '../services/deepgram_flutter_example.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  // Список экранов для отображения
  final List<Widget> _screens = [
    VoiceRecognitionScreen(),
    HistoryScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF121212),
      appBar: AppBar(
        title: Text('Deepgram Voice Assistant'),
        backgroundColor: Color(0xFF1E1E1E),
        elevation: 0,
        centerTitle: true,
      ),
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        backgroundColor: Color(0xFF1E1E1E),
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.mic),
            label: 'Запись',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'История',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Настройки',
          ),
        ],
      ),
    );
  }
}

// Экран распознавания голоса
class VoiceRecognitionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DeepgramRecorderPage();
  }
}

// Экран истории
class HistoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.history,
            size: 80,
            color: Colors.blue,
          ),
          SizedBox(height: 20),
          Text(
            'История распознаваний',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'Здесь будет отображаться история ваших распознаваний речи',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.grey,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Экран настроек
class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Настройки',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 20),
          ListTile(
            leading: Icon(Icons.language, color: Colors.blue),
            title: Text('Язык распознавания', style: TextStyle(color: Colors.white)),
            subtitle: Text('Русский', style: TextStyle(color: Colors.grey)),
            trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
            onTap: () {
              // Обработчик нажатия
            },
          ),
          Divider(color: Colors.grey.shade800),
          ListTile(
            leading: Icon(Icons.mic, color: Colors.blue),
            title: Text('Качество записи', style: TextStyle(color: Colors.white)),
            subtitle: Text('Высокое', style: TextStyle(color: Colors.grey)),
            trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
            onTap: () {
              // Обработчик нажатия
            },
          ),
          Divider(color: Colors.grey.shade800),
          ListTile(
            leading: Icon(Icons.api, color: Colors.blue),
            title: Text('API ключ Deepgram', style: TextStyle(color: Colors.white)),
            subtitle: Text('Настроить API ключ', style: TextStyle(color: Colors.grey)),
            trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
            onTap: () {
              // Обработчик нажатия
            },
          ),
          Divider(color: Colors.grey.shade800),
          SizedBox(height: 20),
          Center(
            child: Text(
              'Версия приложения: 1.0.0',
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
