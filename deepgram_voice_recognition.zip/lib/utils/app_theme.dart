import 'package:flutter/material.dart';

class AppTheme {
  // Основные цвета
  static const Color primaryColor = Color(0xFF2196F3);  // Синий
  static const Color accentColor = Color(0xFF03A9F4);  // Светло-синий
  static const Color backgroundColor = Color(0xFF121212);  // Темно-серый
  static const Color cardColor = Color(0xFF1E1E1E);  // Серый
  static const Color textColor = Colors.white;
  static const Color subtitleColor = Color(0xFFB0B0B0);  // Светло-серый

  // Градиенты
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primaryColor, accentColor],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Стили текста
  static const TextStyle headingStyle = TextStyle(
    fontSize: 24.0,
    fontWeight: FontWeight.bold,
    color: textColor,
  );

  static const TextStyle titleStyle = TextStyle(
    fontSize: 18.0,
    fontWeight: FontWeight.w600,
    color: textColor,
  );

  static const TextStyle subtitleStyle = TextStyle(
    fontSize: 16.0,
    color: subtitleColor,
  );

  static const TextStyle bodyStyle = TextStyle(
    fontSize: 16.0,
    color: textColor,
  );

  // Тема приложения
  static ThemeData get darkTheme {
    return ThemeData(
      scaffoldBackgroundColor: backgroundColor,
      primaryColor: primaryColor,
      colorScheme: ColorScheme.dark(
        primary: primaryColor,
        secondary: accentColor,
        background: backgroundColor,
        surface: cardColor,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: cardColor,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: titleStyle.copyWith(fontSize: 20),
      ),
      cardTheme: CardTheme(
        color: cardColor,
        elevation: 4,
        margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      textTheme: TextTheme(
        displayLarge: headingStyle,
        titleLarge: titleStyle,
        bodyLarge: bodyStyle,
        bodyMedium: subtitleStyle,
      ),
      iconTheme: IconThemeData(
        color: textColor,
        size: 24,
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: cardColor,
        selectedItemColor: primaryColor,
        unselectedItemColor: subtitleColor,
        type: BottomNavigationBarType.fixed,
        elevation: 8,
      ),
    );
  }
}
