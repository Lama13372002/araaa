import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/io.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import '../widgets/custom_button.dart';
import '../utils/app_theme.dart';

class DeepgramRecorderPage extends StatefulWidget {
  @override
  _DeepgramRecorderPageState createState() => _DeepgramRecorderPageState();
}

class _DeepgramRecorderPageState extends State<DeepgramRecorderPage> with SingleTickerProviderStateMixin {
  // Deepgram API настройки
  final String apiKey = '80c36664946f61d6ec858eb771fbfe919814887b'; // Замените своим API ключом
  final String wsUrl = 'wss://api.deepgram.com/v1/listen?model=nova-3&language=ru&punctuate=true&interim_results=true&encoding=linear16&sample_rate=16000';

  // Состояние записи и распознавания
  bool isRecording = false;
  String transcription = '';
  String status = 'Нажмите на кнопку, чтобы начать запись';

  // WebSocket и запись звука
  WebSocketChannel? channel;
  FlutterSoundRecorder? audioRecorder;
  StreamSubscription? recorderSubscription;

  // Анимация для кнопки
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _initAudioRecorder();

    // Инициализируем анимацию
    _animationController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    );

    _animation = Tween<double>(begin: 1.0, end: 1.2).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _animationController.repeat(reverse: true);
  }

  Future<void> _initAudioRecorder() async {
    // Запрос разрешений
    final status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      setState(() {
        this.status = 'Для работы приложения необходим доступ к микрофону';
      });
      return;
    }

    audioRecorder = FlutterSoundRecorder();
    await audioRecorder!.openRecorder();

    // Проверяем, что рекордер инициализирован корректно
    if (audioRecorder == null || !(await audioRecorder!.isEncoderSupported(Codec.pcm16))) {
      setState(() {
        this.status = 'Ошибка инициализации записи';
      });
    }
  }

  Future<void> _connectToDeepgram() async {
    try {
      setState(() {
        status = 'Подключение к серверу...';
      });

      // Создаем WebSocket соединение с Deepgram
      // Обратите внимание: в URL мы указываем формат encoding=linear16 и sample_rate=16000
      final wsUri = Uri.parse(wsUrl);
      channel = IOWebSocketChannel.connect(
        wsUri,
        headers: {
          'Authorization': 'Token $apiKey',
        },
      );

      // Обработка сообщений от Deepgram
      channel!.stream.listen(
        (dynamic message) {
          _handleDeepgramMessage(message);
        },
        onError: (error) {
          print('WebSocket error: $error');
          setState(() {
            status = 'Ошибка подключения к серверу';
          });
          _stopRecording();
        },
        onDone: () {
          print('WebSocket connection closed');
          if (isRecording) {
            setState(() {
              status = 'Соединение разорвано';
            });
            _stopRecording();
          }
        },
      );

      setState(() {
        status = 'Запись...';
      });
    } catch (e) {
      print('Error connecting to Deepgram: $e');
      setState(() {
        status = 'Ошибка: $e';
      });
    }
  }

  void _handleDeepgramMessage(dynamic message) {
    try {
      final Map<String, dynamic> data = json.decode(message);

      // Проверяем наличие данных транскрипции
      if (data.containsKey('channel') &&
          data['channel'].containsKey('alternatives') &&
          data['channel']['alternatives'].isNotEmpty) {

        final String transcript = data['channel']['alternatives'][0]['transcript'];
        if (transcript.trim().isEmpty) return;

        setState(() {
          if (data['is_final'] == true) {
            transcription += '\n\nВы: $transcript';
          } else {
            // Обновляем последнее высказывание (интерим результат)
            final parts = transcription.split('\n\n');
            if (parts.length > 0 && parts.last.startsWith('Вы: ')) {
              parts[parts.length - 1] = 'Вы: $transcript';
              transcription = parts.join('\n\n');
            } else {
              transcription += '\n\nВы: $transcript';
            }
          }
        });
      }
    } catch (e) {
      print('Error parsing message: $e');
    }
  }

  Future<void> _startRecording() async {
    if (audioRecorder == null) return;

    // Сначала устанавливаем соединение с Deepgram
    await _connectToDeepgram();
    if (channel == null) {
      setState(() {
        status = 'Не удалось подключиться к серверу';
      });
      return;
    }

    try {
      // Начинаем запись аудио в формате PCM
      // Важно: используем Codec.pcm16 вместо pcm16WAV, чтобы получить сырые PCM данные
      String tempPath = (await getTemporaryDirectory()).path;
      await audioRecorder!.startRecorder(
        toFile: '$tempPath/temp.pcm',  // Изменено расширение на .pcm
        codec: Codec.pcm16,  // Используем PCM без WAV-заголовка
        sampleRate: 16000,   // 16kHz, что оптимально для распознавания речи
        numChannels: 1,      // Моно канал
      );

      // Слушаем данные с микрофона и отправляем их в Deepgram
      recorderSubscription = audioRecorder!.onProgress!.listen((RecordingDisposition event) {
        // Deepgram работает с порциями аудио данных
        // Мы должны периодически отправлять данные с микрофона
        _sendAudioData();
      });

      setState(() {
        isRecording = true;
      });
    } catch (e) {
      print('Error starting recorder: $e');
      setState(() {
        status = 'Ошибка начала записи: $e';
      });

      // Закрываем соединение, если запись не удалась
      if (channel != null) {
        channel!.sink.close();
        channel = null;
      }
    }
  }

  // Новый метод для отправки аудиоданных
  Future<void> _sendAudioData() async {
    if (channel == null || !isRecording) return;

    try {
      String tempPath = (await getTemporaryDirectory()).path;
      final file = File('$tempPath/temp.pcm');

      if (await file.exists()) {
        // Читаем только последние ~100ms аудио из файла
        // Это предотвращает отправку всего файла каждый раз и снижает задержку
        final stats = await file.stat();
        final fileSize = stats.size;

        // Если файл больше 3200 байт (100ms аудио при 16kHz, 16-bit, 1 канал),
        // читаем только последние 3200 байт
        // 16000 (sample rate) * 2 (bytes per sample) * 0.1 (seconds) = 3200 bytes
        const int chunkSize = 3200;

        Uint8List audioData;
        if (fileSize > chunkSize) {
          final raf = await file.open(mode: FileMode.read);
          await raf.setPosition(fileSize - chunkSize);
          audioData = await raf.read(chunkSize);
          await raf.close();
        } else {
          audioData = await file.readAsBytes();
        }

        if (audioData.isNotEmpty && channel != null) {
          // Отправляем данные через WebSocket
          channel!.sink.add(audioData);
        }
      }
    } catch (e) {
      print('Error sending audio data: $e');
    }
  }

  void _stopRecording() async {
    // Останавливаем запись
    if (audioRecorder != null && audioRecorder!.isRecording) {
      await audioRecorder!.stopRecorder();
    }

    // Отключаем стрим аудио
    if (recorderSubscription != null) {
      recorderSubscription!.cancel();
      recorderSubscription = null;
    }

    // Закрываем WebSocket
    if (channel != null) {
      channel!.sink.close();
      channel = null;
    }

    setState(() {
      isRecording = false;
      status = 'Нажмите на кнопку, чтобы начать запись';
    });
  }

  void _toggleRecording() async {
    if (!isRecording) {
      await _startRecording();
    } else {
      _stopRecording();
    }
  }

  void _clearTranscription() {
    setState(() {
      transcription = '';
    });
  }

  @override
  void dispose() {
    _stopRecording();
    audioRecorder?.closeRecorder();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: Column(
        children: [
          // Область транскрипции
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.cardColor,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  // Кнопка очистки транскрипции
                  if (transcription.isNotEmpty)
                    IconButton(
                      icon: Icon(Icons.clear, color: Colors.grey),
                      onPressed: _clearTranscription,
                      tooltip: 'Очистить текст',
                    ),
                  // Текст транскрипции
                  Expanded(
                    child: SingleChildScrollView(
                      child: Text(
                        transcription.isEmpty ? 'Здесь появится распознанный текст...' : transcription,
                        style: transcription.isEmpty
                            ? AppTheme.subtitleStyle
                            : AppTheme.bodyStyle,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Статус и кнопка записи
          Container(
            padding: EdgeInsets.symmetric(vertical: 20),
            color: AppTheme.backgroundColor,
            child: Column(
              children: [
                // Статус
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    status,
                    style: AppTheme.subtitleStyle,
                    textAlign: TextAlign.center,
                  ),
                ),

                // Кнопка записи
                ScaleTransition(
                  scale: isRecording ? _animation : const AlwaysStoppedAnimation(1.0),
                  child: GestureDetector(
                    onTap: _toggleRecording,
                    child: Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: isRecording ? Colors.red : AppTheme.primaryColor,
                        borderRadius: BorderRadius.circular(40),
                        boxShadow: [
                          BoxShadow(
                            color: (isRecording ? Colors.red : AppTheme.primaryColor).withOpacity(0.5),
                            blurRadius: 10,
                            offset: Offset(0, 5),
                            spreadRadius: 2,
                          ),
                        ],
                        gradient: isRecording
                            ? LinearGradient(
                                colors: [Colors.red.shade600, Colors.red.shade400],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              )
                            : AppTheme.primaryGradient,
                      ),
                      child: Icon(
                        isRecording ? Icons.stop : Icons.mic,
                        color: Colors.white,
                        size: 32,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 40),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class File {
  final String path;

  File(this.path);

  Future<bool> exists() async {
    try {
      final response = await http.get(Uri.parse('file://$path'));
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  Future<Uint8List> readAsBytes() async {
    final response = await http.get(Uri.parse('file://$path'));
    return response.bodyBytes;
  }

  Future<RandomAccessFile> open({required FileMode mode}) async {
    return RandomAccessFile(path);
  }

  Future<FileStat> stat() async {
    try {
      final response = await http.get(Uri.parse('file://$path'));
      return FileStat(response.bodyBytes.length);
    } catch (e) {
      return FileStat(0);
    }
  }
}

class RandomAccessFile {
  final String path;
  int _position = 0;

  RandomAccessFile(this.path);

  Future<void> setPosition(int position) async {
    _position = position;
  }

  Future<Uint8List> read(int count) async {
    final response = await http.get(Uri.parse('file://$path'));
    final bytes = response.bodyBytes;

    if (_position >= bytes.length) {
      return Uint8List(0);
    }

    final end = _position + count > bytes.length ? bytes.length : _position + count;
    return bytes.sublist(_position, end);
  }

  Future<void> close() async {}
}

class FileStat {
  final int size;

  FileStat(this.size);
}

enum FileMode {
  read,
  write,
  append,
  writeOnly,
  writeOnlyAppend,
}
